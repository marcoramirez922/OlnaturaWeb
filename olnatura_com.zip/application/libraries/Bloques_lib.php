<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bloques_lib{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct(){
		$this->CI =& get_instance();
	}
		
	public function iniArmado($idRelacion,$SeccionTipo){
		$data["dataDesple"]= "";
		
		$this->CI->load->model('Bloques_mod');
				$data["dataDesple"].= '<div class="row">';
				$data["dataDesple"].= '	<div class="container">';
				$data["dataDesple"].= '		<div class="inEspacios" id="seccionID_'.$idRelacion.'" style="margin:0px 10px;">';
				
		$listSecciones= $this->CI->Bloques_mod->getBloques($idRelacion);
		
		foreach($listSecciones as $listSeccione){
					$data["dataDesple"].=		'<div class="col-md-3 col-sm-3 col-xs-12">';
						$data["dataDesple"].=		'<a href="'.$listSeccione->link.'"><div align="center"><img src="../admin/assets/images/slides/'.$listSeccione->imagen.'" /></div>';
							$data["dataDesple"].=		'<div align="center"><h2>'.$listSeccione->titulo.'</h2></div>';
							$data["dataDesple"].=		'<p>'.$listSeccione->texto.'</p>';
						$data["dataDesple"].=		'</a>';
					$data["dataDesple"].=		'</div>';
		}
				$data["dataDesple"].= '		</div>';
				$data["dataDesple"].= '	</div>';
				$data["dataDesple"].= '</div>';
		
		switch(count($listSecciones)){
			case 1:
				$marginProm_767= "1";
				$marginProm_768= "38";
				$marginProm_992= "38";
			break;
			case 2:
				$marginProm_767= "1";
				$marginProm_768= "12";
				$marginProm_992= "12";
			break;
			case 3:
				$marginProm_767= "1";
				$marginProm_768= "2";
				$marginProm_992= "4";
			break;
			case 4:
				$marginProm_767= "1";
				$marginProm_768= "0";
				$marginProm_992= "0";
			break;
		}
				$data["arrStyle"]= '
					<style>@media (max-width: 767px) {
						#seccionID_'.$idRelacion.' div{ margin:10px '.$marginProm_767.'%; }
					}
					@media (min-width: 768px) {
						#seccionID_'.$idRelacion.' div{ margin:0px '.$marginProm_768.'%; }
					}
					@media (min-width: 992px) {
						#seccionID_'.$idRelacion.' div{ margin:0px '.$marginProm_992.'%; }
					}
					</style>
				';
		
		return $data["dataDesple"].$data["arrStyle"];
	}
}
