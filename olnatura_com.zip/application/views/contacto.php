    <div id="example1" class="slider-pro">
		<div class="sp-slides">
			<div class="sp-slide">
				<img class="sp-image" src="<?Php echo base_url(); ?>assets/img/blank.gif"
					data-src="<?Php echo base_url(); ?>admin/assets/images/slides/slide-1.jpg"
					data-retina="<?Php echo base_url(); ?>admin/assets/images/slides/slide-1.jpg"/>
			</div>

	        <div class="sp-slide">
	        	<img class="sp-image" src="<?Php echo base_url(); ?>assets/img/blank.gif"
	        		data-src="<?Php echo base_url(); ?>admin/assets/images/slides/slide-2.jpg"
	        		data-retina="<?Php echo base_url(); ?>admin/assets/images/slides/slide-2.jpg"/>
			</div>

	        <div class="sp-slide">
	        	<img class="sp-image" src="<?Php echo base_url(); ?>assets/img/blank.gif"
	        		data-src="<?Php echo base_url(); ?>admin/assets/images/slides/slide-3.jpg"
	        		data-retina="<?Php echo base_url(); ?>admin/assets/images/slides/slide-3.jpg"/>
			</div>
		</div>
    </div>
    <!-- /container -->
