    <?Php
    echo $Concentrador;
	?>
    
    <!-- /container -->
	<script type="text/javascript">
        $( document ).ready(function( $ ) {
			<?Php 
			if(in_array(1,$loadLibrary)){ ?>
			var slideFull = $("<?Php echo $arrjQuery; ?>").slippry({
				pager: false,
				// transition: 'fade',
				//useCSS: true,
				speed: 3000,
				pause: 7000
				// auto: true,
				// preload: 'visible',
				// autoHover: false
			});
			<?Php } ?>
			
			<?Php if(in_array(2,$loadLibrary)){ ?>
			var slideShort = $("<?Php echo implode(" , ",$arrSlideShort); ?>").slippry({
				pager: true,
				transition: 'horizontal',
				//useCSS: true,
				speed: 2500,
				pause: 6500
				// auto: true,
				// preload: 'visible',
				// autoHover: false
			});
			<?Php } ?>
        });
    </script>
