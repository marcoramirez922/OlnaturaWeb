<?Php
class Menus_mod extends CI_Model {
	public function __construct(){
			parent::__construct();
	}
	
	public function getMenus(){
		#$this -> db -> select('us.usuario_id, pr.perfil_id, pr.perfil, us.nombre, us.apellido_paterno, us.email, pr.imagen, us.usuario, us.password');
		$this -> db -> from('menus AS mn');
		#$this -> db -> join('perfiles as pr','pr.perfil_id=us.perfil_id','inner');
		#$this -> db -> where('mn.padre', "0");
		$this -> db -> order_by('mn.padre , mn.orden');
		#$this -> db -> limit(1);

		$query = $this -> db -> get();
		if($query -> num_rows() != 0){
			return $query->result();
		}
		else{
			return "err";
		}
	}
	
	public function getMenusPropiedades($menu){
		$this -> db -> select('mp.*');
		$this -> db -> from('menus_propiedades AS mp');
		$this -> db -> join('menus AS mn','mn.menu_id=mp.menu_id','inner');
		$this -> db -> where('mn.link', $menu);
		$this -> db -> order_by('mn.padre, mn.orden');

		$query = $this -> db -> get();
		if($query -> num_rows() != 0){
			return $query->result();
		}
		else{
			return "err";
		}
	}
}
